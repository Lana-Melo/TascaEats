docker compose up --build
